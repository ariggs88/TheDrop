﻿namespace TheDrop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLoseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveThemeForStartupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveANewThemeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.programsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFolderDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.preferencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeBackgroundImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalWindowSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullscreencoversTaskbarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.themeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCurrentThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lightThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darkThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blueThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greenThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yellowThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purpleThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orangeThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveANEWThemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hideLeftPaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showLeftPaneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeIconDirectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iconPreferencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fixed3DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fixedSIngleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addWebsiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.volumeUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.volumeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.muteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.leftPanelFontDialog = new System.Windows.Forms.FontDialog();
            this.leftPanelColorDialog = new System.Windows.Forms.ColorDialog();
            this.btnGoogleSearch = new System.Windows.Forms.Button();
            this.txtBoxSearch = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lblClock = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.DeleteMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AllowDrop = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("flowLayoutPanel1.BackgroundImage")));
            this.flowLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Garamond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 29, 4, 5);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(40, 40, 40, 69);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1114, 782);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.Click += new System.EventHandler(this.flowLayoutPanel1_Click);
            this.flowLayoutPanel1.DragDrop += new System.Windows.Forms.DragEventHandler(this.FlowLayoutPanel1_DragDrop);
            this.flowLayoutPanel1.DragEnter += new System.Windows.Forms.DragEventHandler(this.FlowLayoutPanel1_DragEnter);
            this.flowLayoutPanel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.flowLayoutPanel1_MouseClick);
            this.flowLayoutPanel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.flowLayoutPanel1_MouseDown);
            // 
            // treeView1
            // 
            this.treeView1.AllowDrop = true;
            this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView1.BackColor = System.Drawing.Color.White;
            this.treeView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.treeView1.Font = new System.Drawing.Font("Garamond", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView1.ForeColor = System.Drawing.Color.Black;
            this.treeView1.FullRowSelect = true;
            this.treeView1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.treeView1.Location = new System.Drawing.Point(0, 38);
            this.treeView1.Margin = new System.Windows.Forms.Padding(30, 29, 30, 29);
            this.treeView1.Name = "treeView1";
            this.treeView1.ShowLines = false;
            this.treeView1.Size = new System.Drawing.Size(218, 712);
            this.treeView1.TabIndex = 1;
            this.treeView1.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.treeView1_ItemDrag);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            this.treeView1.DragLeave += new System.EventHandler(this.treeView1_DragLeave);
            this.treeView1.DoubleClick += new System.EventHandler(this.treeView1_DoubleClick);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.flowLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(1340, 782);
            this.splitContainer1.SplitterDistance = 220;
            this.splitContainer1.SplitterWidth = 6;
            this.splitContainer1.TabIndex = 2;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightGray;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.programsToolStripMenuItem,
            this.editToolStripMenuItem,
            this.addWebsiteToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.volumeUpToolStripMenuItem,
            this.volumeToolStripMenuItem,
            this.muteToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(1340, 35);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.menuStrip1_MouseDown);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.Color.Silver;
            this.fileToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.cLoseToolStripMenuItem,
            this.saveThemeForStartupToolStripMenuItem,
            this.saveANewThemeToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 29);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.aboutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(285, 30);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // cLoseToolStripMenuItem
            // 
            this.cLoseToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.cLoseToolStripMenuItem.Name = "cLoseToolStripMenuItem";
            this.cLoseToolStripMenuItem.Size = new System.Drawing.Size(285, 30);
            this.cLoseToolStripMenuItem.Text = "Close";
            this.cLoseToolStripMenuItem.Click += new System.EventHandler(this.CLoseToolStripMenuItem_Click);
            // 
            // saveThemeForStartupToolStripMenuItem
            // 
            this.saveThemeForStartupToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveThemeForStartupToolStripMenuItem.Name = "saveThemeForStartupToolStripMenuItem";
            this.saveThemeForStartupToolStripMenuItem.Size = new System.Drawing.Size(285, 30);
            this.saveThemeForStartupToolStripMenuItem.Text = "Save Theme For Startup";
            this.saveThemeForStartupToolStripMenuItem.Click += new System.EventHandler(this.saveThemeForStartupToolStripMenuItem_Click);
            // 
            // saveANewThemeToolStripMenuItem1
            // 
            this.saveANewThemeToolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveANewThemeToolStripMenuItem1.Enabled = false;
            this.saveANewThemeToolStripMenuItem1.Name = "saveANewThemeToolStripMenuItem1";
            this.saveANewThemeToolStripMenuItem1.Size = new System.Drawing.Size(285, 30);
            this.saveANewThemeToolStripMenuItem1.Text = "Save a New Theme";
            // 
            // programsToolStripMenuItem
            // 
            this.programsToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.programsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFolderDirectoryToolStripMenuItem,
            this.addProgramToolStripMenuItem,
            this.deleteProgramToolStripMenuItem});
            this.programsToolStripMenuItem.Name = "programsToolStripMenuItem";
            this.programsToolStripMenuItem.Size = new System.Drawing.Size(166, 29);
            this.programsToolStripMenuItem.Text = "Programs/Folders";
            // 
            // addFolderDirectoryToolStripMenuItem
            // 
            this.addFolderDirectoryToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.addFolderDirectoryToolStripMenuItem.Name = "addFolderDirectoryToolStripMenuItem";
            this.addFolderDirectoryToolStripMenuItem.Size = new System.Drawing.Size(264, 30);
            this.addFolderDirectoryToolStripMenuItem.Text = "Add Folder/Directory";
            this.addFolderDirectoryToolStripMenuItem.Click += new System.EventHandler(this.addFolderDirectoryToolStripMenuItem_Click);
            // 
            // addProgramToolStripMenuItem
            // 
            this.addProgramToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.addProgramToolStripMenuItem.Name = "addProgramToolStripMenuItem";
            this.addProgramToolStripMenuItem.Size = new System.Drawing.Size(264, 30);
            this.addProgramToolStripMenuItem.Text = "Add Program";
            this.addProgramToolStripMenuItem.Click += new System.EventHandler(this.AddProgramToolStripMenuItem_Click);
            // 
            // deleteProgramToolStripMenuItem
            // 
            this.deleteProgramToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.deleteProgramToolStripMenuItem.Name = "deleteProgramToolStripMenuItem";
            this.deleteProgramToolStripMenuItem.Size = new System.Drawing.Size(264, 30);
            this.deleteProgramToolStripMenuItem.Text = "Delete Program";
            this.deleteProgramToolStripMenuItem.Click += new System.EventHandler(this.DeleteProgramToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.preferencesToolStripMenuItem,
            this.changeBackgroundImageToolStripMenuItem,
            this.normalWindowSizeToolStripMenuItem,
            this.fullscreencoversTaskbarToolStripMenuItem,
            this.themeToolStripMenuItem,
            this.saveANEWThemeToolStripMenuItem,
            this.hideLeftPaneToolStripMenuItem,
            this.showLeftPaneToolStripMenuItem,
            this.changeIconDirectionToolStripMenuItem,
            this.iconPreferencesToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // preferencesToolStripMenuItem
            // 
            this.preferencesToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.preferencesToolStripMenuItem.Name = "preferencesToolStripMenuItem";
            this.preferencesToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.preferencesToolStripMenuItem.Text = "Preferences";
            this.preferencesToolStripMenuItem.Click += new System.EventHandler(this.preferencesToolStripMenuItem_Click);
            // 
            // changeBackgroundImageToolStripMenuItem
            // 
            this.changeBackgroundImageToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.changeBackgroundImageToolStripMenuItem.Name = "changeBackgroundImageToolStripMenuItem";
            this.changeBackgroundImageToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.changeBackgroundImageToolStripMenuItem.Text = "Change Background Image";
            this.changeBackgroundImageToolStripMenuItem.Click += new System.EventHandler(this.changeBackgroundImageToolStripMenuItem_Click_1);
            // 
            // normalWindowSizeToolStripMenuItem
            // 
            this.normalWindowSizeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.normalWindowSizeToolStripMenuItem.Name = "normalWindowSizeToolStripMenuItem";
            this.normalWindowSizeToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.normalWindowSizeToolStripMenuItem.Text = "Normal Window Size";
            this.normalWindowSizeToolStripMenuItem.Click += new System.EventHandler(this.normalWindowSizeToolStripMenuItem_Click);
            // 
            // fullscreencoversTaskbarToolStripMenuItem
            // 
            this.fullscreencoversTaskbarToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fullscreencoversTaskbarToolStripMenuItem.Name = "fullscreencoversTaskbarToolStripMenuItem";
            this.fullscreencoversTaskbarToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.fullscreencoversTaskbarToolStripMenuItem.Text = "Fullscreen";
            this.fullscreencoversTaskbarToolStripMenuItem.Click += new System.EventHandler(this.fullscreencoversTaskbarToolStripMenuItem_Click);
            // 
            // themeToolStripMenuItem
            // 
            this.themeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.themeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveCurrentThemeToolStripMenuItem,
            this.lightThemeToolStripMenuItem,
            this.darkThemeToolStripMenuItem,
            this.blueThemeToolStripMenuItem,
            this.redThemeToolStripMenuItem,
            this.greenThemeToolStripMenuItem,
            this.yellowThemeToolStripMenuItem,
            this.purpleThemeToolStripMenuItem,
            this.orangeThemeToolStripMenuItem});
            this.themeToolStripMenuItem.Name = "themeToolStripMenuItem";
            this.themeToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.themeToolStripMenuItem.Text = "Themes";
            // 
            // saveCurrentThemeToolStripMenuItem
            // 
            this.saveCurrentThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveCurrentThemeToolStripMenuItem.Name = "saveCurrentThemeToolStripMenuItem";
            this.saveCurrentThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.saveCurrentThemeToolStripMenuItem.Text = "Save Current Theme";
            this.saveCurrentThemeToolStripMenuItem.Click += new System.EventHandler(this.saveCurrentThemeToolStripMenuItem_Click);
            // 
            // lightThemeToolStripMenuItem
            // 
            this.lightThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lightThemeToolStripMenuItem.Name = "lightThemeToolStripMenuItem";
            this.lightThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.lightThemeToolStripMenuItem.Text = "Light Theme";
            this.lightThemeToolStripMenuItem.Click += new System.EventHandler(this.lightThemeToolStripMenuItem_Click);
            // 
            // darkThemeToolStripMenuItem
            // 
            this.darkThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.darkThemeToolStripMenuItem.Name = "darkThemeToolStripMenuItem";
            this.darkThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.darkThemeToolStripMenuItem.Text = "Dark Theme";
            this.darkThemeToolStripMenuItem.Click += new System.EventHandler(this.darkThemeToolStripMenuItem_Click);
            // 
            // blueThemeToolStripMenuItem
            // 
            this.blueThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.blueThemeToolStripMenuItem.Name = "blueThemeToolStripMenuItem";
            this.blueThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.blueThemeToolStripMenuItem.Text = "Blue Theme";
            this.blueThemeToolStripMenuItem.Click += new System.EventHandler(this.blueThemeToolStripMenuItem_Click);
            // 
            // redThemeToolStripMenuItem
            // 
            this.redThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.redThemeToolStripMenuItem.Name = "redThemeToolStripMenuItem";
            this.redThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.redThemeToolStripMenuItem.Text = "Red Theme";
            this.redThemeToolStripMenuItem.Click += new System.EventHandler(this.redThemeToolStripMenuItem_Click);
            // 
            // greenThemeToolStripMenuItem
            // 
            this.greenThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.greenThemeToolStripMenuItem.Name = "greenThemeToolStripMenuItem";
            this.greenThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.greenThemeToolStripMenuItem.Text = "Green Theme";
            this.greenThemeToolStripMenuItem.Click += new System.EventHandler(this.greenThemeToolStripMenuItem_Click);
            // 
            // yellowThemeToolStripMenuItem
            // 
            this.yellowThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.yellowThemeToolStripMenuItem.Name = "yellowThemeToolStripMenuItem";
            this.yellowThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.yellowThemeToolStripMenuItem.Text = "Yellow Theme";
            this.yellowThemeToolStripMenuItem.Click += new System.EventHandler(this.yellowThemeToolStripMenuItem_Click);
            // 
            // purpleThemeToolStripMenuItem
            // 
            this.purpleThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.purpleThemeToolStripMenuItem.Name = "purpleThemeToolStripMenuItem";
            this.purpleThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.purpleThemeToolStripMenuItem.Text = "Purple Theme";
            this.purpleThemeToolStripMenuItem.Click += new System.EventHandler(this.purpleThemeToolStripMenuItem_Click);
            // 
            // orangeThemeToolStripMenuItem
            // 
            this.orangeThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.orangeThemeToolStripMenuItem.Name = "orangeThemeToolStripMenuItem";
            this.orangeThemeToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.orangeThemeToolStripMenuItem.Text = "Orange Theme";
            this.orangeThemeToolStripMenuItem.Click += new System.EventHandler(this.orangeThemeToolStripMenuItem_Click);
            // 
            // saveANEWThemeToolStripMenuItem
            // 
            this.saveANEWThemeToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.saveANEWThemeToolStripMenuItem.Enabled = false;
            this.saveANEWThemeToolStripMenuItem.Name = "saveANEWThemeToolStripMenuItem";
            this.saveANEWThemeToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.saveANEWThemeToolStripMenuItem.Text = "Save a NEW Theme";
            this.saveANEWThemeToolStripMenuItem.Click += new System.EventHandler(this.saveANEWThemeToolStripMenuItem_Click);
            // 
            // hideLeftPaneToolStripMenuItem
            // 
            this.hideLeftPaneToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.hideLeftPaneToolStripMenuItem.Name = "hideLeftPaneToolStripMenuItem";
            this.hideLeftPaneToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.hideLeftPaneToolStripMenuItem.Text = "Hide Left Pane";
            this.hideLeftPaneToolStripMenuItem.Click += new System.EventHandler(this.hideLeftPaneToolStripMenuItem_Click);
            // 
            // showLeftPaneToolStripMenuItem
            // 
            this.showLeftPaneToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.showLeftPaneToolStripMenuItem.Name = "showLeftPaneToolStripMenuItem";
            this.showLeftPaneToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.showLeftPaneToolStripMenuItem.Text = "Show Left Pane";
            this.showLeftPaneToolStripMenuItem.Click += new System.EventHandler(this.showLeftPaneToolStripMenuItem_Click);
            // 
            // changeIconDirectionToolStripMenuItem
            // 
            this.changeIconDirectionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topDownToolStripMenuItem,
            this.leftToRightToolStripMenuItem,
            this.rightToLeftToolStripMenuItem,
            this.bottomUpToolStripMenuItem});
            this.changeIconDirectionToolStripMenuItem.Name = "changeIconDirectionToolStripMenuItem";
            this.changeIconDirectionToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.changeIconDirectionToolStripMenuItem.Text = "Change Icon Direction";
            // 
            // topDownToolStripMenuItem
            // 
            this.topDownToolStripMenuItem.Name = "topDownToolStripMenuItem";
            this.topDownToolStripMenuItem.Size = new System.Drawing.Size(194, 30);
            this.topDownToolStripMenuItem.Text = "Top Down";
            this.topDownToolStripMenuItem.Click += new System.EventHandler(this.topDownToolStripMenuItem_Click);
            // 
            // leftToRightToolStripMenuItem
            // 
            this.leftToRightToolStripMenuItem.Name = "leftToRightToolStripMenuItem";
            this.leftToRightToolStripMenuItem.Size = new System.Drawing.Size(194, 30);
            this.leftToRightToolStripMenuItem.Text = "Left to Right";
            this.leftToRightToolStripMenuItem.Click += new System.EventHandler(this.leftToRightToolStripMenuItem_Click);
            // 
            // rightToLeftToolStripMenuItem
            // 
            this.rightToLeftToolStripMenuItem.Name = "rightToLeftToolStripMenuItem";
            this.rightToLeftToolStripMenuItem.Size = new System.Drawing.Size(194, 30);
            this.rightToLeftToolStripMenuItem.Text = "Right to Left";
            this.rightToLeftToolStripMenuItem.Click += new System.EventHandler(this.rightToLeftToolStripMenuItem_Click);
            // 
            // bottomUpToolStripMenuItem
            // 
            this.bottomUpToolStripMenuItem.Name = "bottomUpToolStripMenuItem";
            this.bottomUpToolStripMenuItem.Size = new System.Drawing.Size(194, 30);
            this.bottomUpToolStripMenuItem.Text = "Bottom Up";
            this.bottomUpToolStripMenuItem.Click += new System.EventHandler(this.bottomUpToolStripMenuItem_Click);
            // 
            // iconPreferencesToolStripMenuItem
            // 
            this.iconPreferencesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fixed3DToolStripMenuItem,
            this.fixedSIngleToolStripMenuItem,
            this.noneToolStripMenuItem});
            this.iconPreferencesToolStripMenuItem.Name = "iconPreferencesToolStripMenuItem";
            this.iconPreferencesToolStripMenuItem.Size = new System.Drawing.Size(311, 30);
            this.iconPreferencesToolStripMenuItem.Text = "Icon Preferences";
            this.iconPreferencesToolStripMenuItem.Click += new System.EventHandler(this.iconPreferencesToolStripMenuItem_Click);
            // 
            // fixed3DToolStripMenuItem
            // 
            this.fixed3DToolStripMenuItem.Name = "fixed3DToolStripMenuItem";
            this.fixed3DToolStripMenuItem.Size = new System.Drawing.Size(191, 30);
            this.fixed3DToolStripMenuItem.Text = "Fixed 3D";
            this.fixed3DToolStripMenuItem.Click += new System.EventHandler(this.fixed3DToolStripMenuItem_Click);
            // 
            // fixedSIngleToolStripMenuItem
            // 
            this.fixedSIngleToolStripMenuItem.Name = "fixedSIngleToolStripMenuItem";
            this.fixedSIngleToolStripMenuItem.Size = new System.Drawing.Size(191, 30);
            this.fixedSIngleToolStripMenuItem.Text = "Fixed SIngle";
            this.fixedSIngleToolStripMenuItem.Click += new System.EventHandler(this.fixedSIngleToolStripMenuItem_Click);
            // 
            // noneToolStripMenuItem
            // 
            this.noneToolStripMenuItem.Name = "noneToolStripMenuItem";
            this.noneToolStripMenuItem.Size = new System.Drawing.Size(191, 30);
            this.noneToolStripMenuItem.Text = "None";
            this.noneToolStripMenuItem.Click += new System.EventHandler(this.noneToolStripMenuItem_Click);
            // 
            // addWebsiteToolStripMenuItem
            // 
            this.addWebsiteToolStripMenuItem.Name = "addWebsiteToolStripMenuItem";
            this.addWebsiteToolStripMenuItem.Size = new System.Drawing.Size(96, 29);
            this.addWebsiteToolStripMenuItem.Text = "Websites";
            this.addWebsiteToolStripMenuItem.Click += new System.EventHandler(this.addWebsiteToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(61, 29);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(29, 29);
            this.toolStripMenuItem1.Text = " ";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(29, 29);
            this.toolStripMenuItem2.Text = " ";
            // 
            // volumeUpToolStripMenuItem
            // 
            this.volumeUpToolStripMenuItem.Name = "volumeUpToolStripMenuItem";
            this.volumeUpToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.volumeUpToolStripMenuItem.Text = "Volume +";
            this.volumeUpToolStripMenuItem.Click += new System.EventHandler(this.volumeUpToolStripMenuItem_Click);
            this.volumeUpToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.volumeUpToolStripMenuItem_MouseDown);
            // 
            // volumeToolStripMenuItem
            // 
            this.volumeToolStripMenuItem.Name = "volumeToolStripMenuItem";
            this.volumeToolStripMenuItem.Size = new System.Drawing.Size(97, 29);
            this.volumeToolStripMenuItem.Text = "Volume -";
            this.volumeToolStripMenuItem.Click += new System.EventHandler(this.volumeToolStripMenuItem_Click);
            this.volumeToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.volumeToolStripMenuItem_MouseDown);
            // 
            // muteToolStripMenuItem
            // 
            this.muteToolStripMenuItem.Name = "muteToolStripMenuItem";
            this.muteToolStripMenuItem.Size = new System.Drawing.Size(65, 29);
            this.muteToolStripMenuItem.Text = "Mute";
            this.muteToolStripMenuItem.Click += new System.EventHandler(this.muteToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnGoogleSearch
            // 
            this.btnGoogleSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGoogleSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGoogleSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoogleSearch.Location = new System.Drawing.Point(1254, 5);
            this.btnGoogleSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGoogleSearch.Name = "btnGoogleSearch";
            this.btnGoogleSearch.Size = new System.Drawing.Size(86, 29);
            this.btnGoogleSearch.TabIndex = 3;
            this.btnGoogleSearch.Text = "Search";
            this.btnGoogleSearch.UseVisualStyleBackColor = true;
            this.btnGoogleSearch.Click += new System.EventHandler(this.BtnGoogleSearch_Click);
            // 
            // txtBoxSearch
            // 
            this.txtBoxSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxSearch.Location = new System.Drawing.Point(994, 5);
            this.txtBoxSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtBoxSearch.Name = "txtBoxSearch";
            this.txtBoxSearch.Size = new System.Drawing.Size(248, 26);
            this.txtBoxSearch.TabIndex = 4;
            this.txtBoxSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBoxSearch_KeyDown);
            this.txtBoxSearch.MouseEnter += new System.EventHandler(this.txtBoxSearch_MouseEnter);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Font = new System.Drawing.Font("Garamond", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(910, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "GOOGLE";
            // 
            // lblClock
            // 
            this.lblClock.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblClock.AutoSize = true;
            this.lblClock.BackColor = System.Drawing.Color.Transparent;
            this.lblClock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblClock.Font = new System.Drawing.Font("Garamond", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClock.ForeColor = System.Drawing.Color.Black;
            this.lblClock.Location = new System.Drawing.Point(0, 752);
            this.lblClock.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClock.Name = "lblClock";
            this.lblClock.Size = new System.Drawing.Size(68, 27);
            this.lblClock.TabIndex = 6;
            this.lblClock.Text = "label1";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DeleteMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(135, 34);
            this.contextMenuStrip1.Tag = "";
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // DeleteMenuItem
            // 
            this.DeleteMenuItem.Name = "DeleteMenuItem";
            this.DeleteMenuItem.Size = new System.Drawing.Size(134, 30);
            this.DeleteMenuItem.Text = "Delete";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1340, 782);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblClock);
            this.Controls.Add(this.txtBoxSearch);
            this.Controls.Add(this.btnGoogleSearch);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Drop";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.Move += new System.EventHandler(this.Form1_Move);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLoseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProgramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteProgramToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FontDialog leftPanelFontDialog;
        private System.Windows.Forms.ColorDialog leftPanelColorDialog;
        private System.Windows.Forms.Button btnGoogleSearch;
        private System.Windows.Forms.TextBox txtBoxSearch;
        private System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ToolStripMenuItem changeBackgroundImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem preferencesToolStripMenuItem;
        public System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ToolStripMenuItem normalWindowSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fullscreencoversTaskbarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveCurrentThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lightThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem darkThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blueThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greenThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yellowThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purpleThemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orangeThemeToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem addWebsiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem volumeUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem volumeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem muteToolStripMenuItem;
        public System.Windows.Forms.Label lblClock;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        public System.Windows.Forms.ToolStripMenuItem DeleteMenuItem;
        public System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem saveANEWThemeToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem themeToolStripMenuItem;
        public System.Windows.Forms.SplitContainer splitContainer1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem programsToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFolderDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hideLeftPaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showLeftPaneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveThemeForStartupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveANewThemeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem changeIconDirectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topDownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iconPreferencesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fixed3DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem fixedSIngleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noneToolStripMenuItem;
    }
}

